package com.muharremtopakkaya.kotlinlearn

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Variables

        var x = 5
        var y = 4

        println(x*y)
        var age=35
        val result = age /7*5;
        println(result)
        //Defining tanımlamak
        val myInteger :Int // tam sayı olmayan bir değer atayamayız.
        //Inıtalize başlatmak ilk değerini atamak
        myInteger = 10
        //myInteger = 20  val olduğu için sabit değiştiremeyiz
          println("-----Integer-----")
        val a:Int=23; // istersek değer atayabiliriz.
        println(a/5); // tam sayı atar. otomatik.
        println(x+y)


        println(age /5 *5)
        age=36
        println(age)
        //Constants

       // val name = "James"
        // name="Muharrem" yapamazsın
        // val sabittir sonradan değişim mümkün değil
        // var değişken olduğu için bunda mümkün

        val pi=3.14
        println(pi * 2.0)

        val myFloat =3.14f
        println(myFloat *2)
        var myAge:Double
        myAge=23.0
        println(myAge/2)

        //camelCase
        //snake_case
        println("-------String-------")
        val myString="atil samancioglu"
        val name="James"
        val surname="Hetfield"
        val fullname=name+""+surname
        println(fullname)
        val larsName:String="Lars"
        println(myString.capitalize())  // atilın a sı büyük yazılır

        println("--------Boolean---------")
        var myBoolean : Boolean = true
        myBoolean = false
        var isAlive = true


    }
}